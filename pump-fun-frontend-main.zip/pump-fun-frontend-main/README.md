## Basic frontend for pump.fun

Many parts are under private status.

You can check smart contract and backend repo as well.

You can contact me if you want a better product.

Telegram: https://t.me/microgift88

Discord: https://discord.com/users/1074514238325927956
